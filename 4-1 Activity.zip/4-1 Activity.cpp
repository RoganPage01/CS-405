#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class MyCustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "My custom exception occurred!";  // Custom message for our exception
    }
};

bool do_even_more_custom_application_logic()
{
    // Simulating an exception being thrown (e.g., std::invalid_argument)
    throw std::invalid_argument("Something went wrong in even more custom application logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

void do_custom_application_logic()
{
    // Wrap the call to do_even_more_custom_application_logic() with exception handling
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // Catch any standard exception and display the error message
        std::cout << "Caught an exception: " << ex.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception
    throw MyCustomException();  // Example of throwing a custom exception

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throw an exception for divide by zero using std::invalid_argument
    if (den == 0.0f) {
        throw std::invalid_argument("Error: Division by zero.");
    }
    return (num / den);
}

void do_division() noexcept
{
    // Exception handler to catch only the exception thrown by divide
    try {
        float numerator = 10.0f;
        float denominator = 0.0f; // This will cause a division by zero error

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) {
        // Only catch std::invalid_argument exceptions
        std::cout << "Caught an exception: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();  // Will catch division by zero
        do_custom_application_logic(); // Will throw and catch custom exception
    }
    catch (const MyCustomException& ex) {
        // Catch the custom exception
        std::cout << "Caught custom exception: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        // Catch any other standard exception
        std::cout << "Caught standard exception: " << ex.what() << std::endl;
    }
    catch (...) {
        // Catch any uncaught exception
        std::cout << "Caught an unknown exception!" << std::endl;
    }

    std::cout << "Program completed." << std::endl;
    return 0;
}
