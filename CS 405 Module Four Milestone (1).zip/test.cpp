// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <stdexcept>

// the global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        srand(time(nullptr));
    }

    void TearDown() override {}
};

class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    for (int entries : {0, 1, 5, 10})
    {
        add_entries(entries);
        ASSERT_GE(collection->max_size(), collection->size());
        collection->clear();
    }
}

TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    for (int entries : {0, 1, 5, 10})
    {
        add_entries(entries);
        ASSERT_GE(collection->capacity(), collection->size());
        collection->clear();
    }
}

TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    ASSERT_TRUE(collection->empty());

    collection->resize(10);

    ASSERT_EQ(collection->size(), 10);
}

TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);

    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingDecreasesCollectionToZero)
{
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);

    collection->resize(0);
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->clear();

    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10);

    collection->erase(collection->begin(), collection->end());

    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    auto initial_capacity = collection->capacity();

    collection->reserve(50);

    ASSERT_GT(collection->capacity(), initial_capacity);
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, OutOfRangeThrowsException)
{
    add_entries(5);
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

TEST_F(CollectionTest, PositiveTestSumOfElements)
{
    add_entries(5);
    int sum = 0;
    for (int val : *collection)
        sum += val;

    ASSERT_GT(sum, 0);
}

TEST_F(CollectionTest, NegativeTestAccessOutOfBounds)
{
    add_entries(5);
    EXPECT_THROW(collection->at(100), std::out_of_range);
}
